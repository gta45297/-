



//=============================================================
//    OLED MODULE 1602   I2C
//    Contraller :
//    Author     :
//    history     :
//==============================================================
#include    <reg51.h>
#include    <stdio.h>          // define I/O functions
#include    <INTRINS.H>      // KEIL FUNCTION

//#define   Data_BUS    P1


//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
sbit SCL    =P1^0;              // Serial Clock Input //D0
sbit SDA    =P1^1;              // Serial Data Input //D1,D2

//#define RES   P3_3                // Reset
sbit SA0    =P3^0;              // Slave Address Bit (D/C# for SA0)

sbit        RES     =P3^1; //PIN15
sbit        CS      =P3^6; //PIN16

//sbit      busy    =P1^7;
//sbit      RS      =P3^0;
//sbit      RW      =P3^7;
//sbit      E       =P3^4;

//sbit        STP     =P2^0;
//sbit        S_S     =P2^1;

char bdata  flag;
sbit busy_f  = flag^0;

void delay(unsigned char);
void CGRAM(void);
void WriteSerialData(unsigned char,unsigned char *);
void CheckBusy(void);
void Write_Command(unsigned char);
void Write_Data(unsigned char dat);
void Initial_SSD1311(void);
void FULL_ON(void);
void SHOW_CHAR(void);
void SHOW_CHARABCD(void);
void SQUARE(void) ;
void CROSS_DOT(void);
void CROSS_DOT2(void);
void SHOW_FONT(void) ;
void SHOW_WB(unsigned char m);
void ENT_SLEEP(void) ;
void EXIT_SLEEP(void);
void STP_SC(void);





//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//  Delay Time
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
void uDelay(unsigned char l)
{
    while(l--);
}


/*=============================================================================
               DISPLAY DATA
===============================================================================*/
unsigned char code Page1[20]  ={"  ECO DISPLAY       "};
unsigned char code Page2[20]  ={"  16 X 02 OLED      "};



// CGRAM has up to 8 characters of 5 x 8 dots, selectable by OPR0 and OPR1 pins
unsigned char code CGRAM1[40] ={0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF, //��     00H
                                 0x1F,0x11,0x11,0x11,0x11,0x11,0x11,0x1F, //��        01H
                                 0x0A,0x15,0x0A,0x15,0x0A,0x15,0x0A,0x15, //��        02H
                                 0x15,0x0A,0x15,0x0A,0x15,0x0A,0x15,0x0A,}; //��      03H

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
void CheckBusy(void)
{
        uDelay(200);//

}

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//  Read/Write Sequence
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
void I2C_O(unsigned char mcmd)
{
unsigned char length = 8;           // Send Command

    while(length--)
    {
        if(mcmd & 0x80)
        {
            SDA=1;
        }
        else
        {
            SDA=0;
        }
        uDelay(3);
        SCL=1;
        uDelay(3);
        SCL=0;
        uDelay(3);
        mcmd = mcmd << 1;
    }
}


void I2C_Ack()
{
    SDA=1;
    uDelay(3);
    SCL=1;
    uDelay(3);
    SCL=0;
    uDelay(3);
}


void I2C_NAck()
{
    SDA=0;
    uDelay(3);
    SCL=1;
    uDelay(3);
    SCL=0;
    uDelay(3);
}


void I2C_Start()
{
    SDA=0;
    uDelay(3);
    SCL=1;
    uDelay(3);
    SCL=0;
    uDelay(3);
    I2C_O(0x78);//w
    I2C_Ack();
}


void I2C_Stop()
{
    SCL=1;
    uDelay(5);
    SDA=0;
    uDelay(5);
    SDA=1;
    uDelay(5);
}


void Write_Command(unsigned char Data)
{
    I2C_Start();
    I2C_O(0x00);
    I2C_Ack();
    I2C_O(Data);
    I2C_Ack();
    I2C_Stop();
}


void Write_Data(unsigned char Data)
{
    I2C_Start();
    I2C_O(0x40);
    I2C_Ack();
    I2C_O(Data);
    I2C_Ack();
    I2C_Stop();
}
//=================================
void WriteSerialData(unsigned char count,unsigned char * MSG)
{
    unsigned char  i;

    CheckBusy();

    for(i = 0; i<count;i++)
    {
        Write_Data(MSG[i]);
    }
}

//=================================


//=================================
void Initial_SSD1311(void)
{
    Write_Command(0x2A);    //Enable Internal Regulator
    Write_Command(0x08);
    Write_Command(0x71);
    Write_Data(0x5C);
    Write_Command(0x28);

    Write_Command(0x08);//Set Display Off

    Write_Command(0x2A);
    Write_Command(0x79);    //Set Display Clock Divide Ratio/Oscillator Frequency
    Write_Command(0XD5);    //
    Write_Command(0x70);    //
    Write_Command(0X78);    //

    Write_Command(0x08);    //Set Display Mode 0x09= 3 or "4" line; 0x08= 1 or "2" line

    Write_Command(0X06);    // Set Re-map

    Write_Command(0x72);//CGROM CDRAM Management
    Write_Data(0x00);

    Write_Command(0x79);//Set OLED Characterization

    Write_Command(0xDA);    //Set SEG Pins Hardware Configuration
    Write_Command(0X10);    //

    Write_Command(0xDC);    //Set Segment Low Voltage & Vcc On
    Write_Command(0x03);

    delay(1);

    Write_Command(0X81);    //Set Contrast Control
    Write_Command(0xFF);    //Contrast increases as the value increases.

    Write_Command(0XD9);    //Set Pre-Charge Period
    Write_Command(0xF1);



    Write_Command(0XDB);    //Set VCOMH Deselect Level
    Write_Command(0x40);

    Write_Command(0x78);    //Exiting Set OLED Characterization
    Write_Command(0x28);

    Write_Command(0x08);//Set CGRAM
    CGRAM();

    Write_Command(0x01);// Clear Display //
    delay(5);                           //Delay

    Write_Command(0x80);    //Set display data RAM addr=00H (SET ADDRESS    80H)

    Write_Command(0x0C);    // Display ON   = 00001DCB (DISPLAY SET 0 1 D C B   0CH);Display ON,Cursor&Blink OFF
}

//============================================
void delay(unsigned char m)   //Delay
{
    unsigned char i,j,k;
     for(j = 0;j<m;j++)
    {
        for(k = 0; k<100;k++)     //250
        {
            for(i = 0; i<200;i++)
            {
            }
        }
    }
}
//========SET CG_RAM DATA==========================
void CGRAM(void)
{
    Write_Command(0x40);
    WriteSerialData(40,CGRAM1);
}

//=================================================
void FULL_ON(void)
{
   unsigned char i;

   Write_Command(0x80); //Set display data RAM addr=00H
   for(i=20;i>0;i--)
   {
      Write_Data(0x00);  
  }
   Write_Command(0xC0); //Set display data RAM addr=40H
   for(i=20;i>0;i--)
   {
      Write_Data(0x00);
   }

}
//=================================================
void SHOW_CHAR(void){
   // unsigned char i;

    Write_Command(0x80);    //Set display data RAM addr=00H
    WriteSerialData(20,Page1);

    Write_Command(0xC0);    //Set display data RAM addr=40H
    WriteSerialData(20,Page2);

}
//===================================================
//                       SHOW_CHARABCD
//===================================================
void SHOW_CHARABCD(void)
 {
    unsigned char i,j;

    Write_Command(0x80);     //Set display data RAM addr=00H
    j=0x41;
    for(i=20;i>0;i--)
    {
      Write_Data(j);
      j++;
    }

    Write_Command(0xC0);    //Set display data RAM addr=40H
    j=0x41;
    for(i=20;i>0;i--)
    {
      Write_Data(j);
      j++;
    }

 }

//=======================================
//               SQUARE
//=======================================
 void SQUARE(void)
{
    unsigned char i;

    Write_Command(0x80);     //Set display data RAM addr=00H
    for(i=20;i>0;i--)
    {
      Write_Data(0x01);
    }

    Write_Command(0xC0);    //Set display data RAM addr=40H
    for(i=20;i>0;i--)
    {
      Write_Data(0x01);
    }


}

//=======================================
//               CK_SHORT1 //3C
//=======================================
 void CK_SHORT1(void)
{
 unsigned char i;

    Write_Command(0x80);     //Set display data RAM addr=00H

    for(i=20;i>0;i--)
    {
      Write_Data(0x3C);

    }

    Write_Command(0xC0);    //Set display data RAM addr=40H
    for(i=20;i>0;i--)
    {
      Write_Data(0x3C);
    }

}

//=======================================
//               CK_SHORT2 //3E
//=======================================
 void CK_SHORT2(void)
{
  unsigned char i;

    Write_Command(0x80);     //Set display data RAM addr=00H

    for(i=20;i>0;i--)
    {
      Write_Data(0x3E);

    }

    Write_Command(0xC0);    //Set display data RAM addr=40H
    for(i=20;i>0;i--)
    {
      Write_Data(0x3E);
    }
}
//=======================================
//               CROSS DOT
//=======================================
 void CROSS_DOT(void)
{
    unsigned char i;

    Write_Command(0x80);     //Set display data RAM addr=00H

    for(i=20;i>0;i--)
    {
      Write_Data(0x02);

    }

    Write_Command(0xC0);    //Set display data RAM addr=40H
    for(i=20;i>0;i--)
    {
      Write_Data(0x02);
    }
}
//=======================================
//               CROSS DOT2
//=======================================
 void CROSS_DOT2(void)
{
    unsigned char i;

    Write_Command(0x80);     //Set display data RAM addr=00H

    for(i=20;i>0;i--)
    {
      Write_Data(0x03);
    }

    Write_Command(0xC0);    //Set display data RAM addr=40H
    for(i=20;i>0;i--)
    {
      Write_Data(0x03);
    }

}

//=======================================
//               SHOW_FONT
//=======================================
 void SHOW_FONT(void)
{
    unsigned char i;

    Write_Command(0x80);     //Set display data RAM addr=00H

    for(i=20;i>0;i--)
    {
      Write_Data(0xA7);
    }

    Write_Command(0xC0);    //Set display data RAM addr=40H
    for(i=20;i>0;i--)
    {
      Write_Data(0xA7);
    }
}
//===========SHOW BLACK AND WHITE==========//
void SHOW_WB(unsigned char m)
{
   unsigned char i,j;
   Write_Command(0x80);
   for(i=5;i>0;i--)
   {
     for(j=1;j<=4;j++ )
     {

       if(j==m)  Write_Data(0x00); else Write_Data(0x20); }
    }
    Write_Command(0xC0);
    if(m==2) m=4; else m=(m+2)%4 ;
    for(i=5;i>0;i--)
   {
     for(j=1;j<=4;j++ )
     {
      if(j==m)  Write_Data(0x00); else Write_Data(0x20); }
   }

}


//=======Entering Sleep Mode=============
void ENT_SLEEP(void)
{
    Write_Command(0x2A);    /*  RE : 1  ; IS : 0  ; SD : 0 */
    Write_Command(0x79);    /*  RE : 1  ; IS : 0  ; SD : 1 */
    Write_Command(0xDC);    //Set VSL & GPIO (Vcc)
    Write_Command(0x02);    // Vcc OFF

    Write_Command(0x78);    /*  RE : 1  ; IS : 0  ; SD : 0 */
    Write_Command(0x28);    //
    Write_Command(0x08);    //Set Regulator

    Write_Command(0x2A);    /*  RE : 1  ; IS : 0  ; SD : 0 */
    Write_Command(0x71);    //
    Write_Data(0x00);//
    Write_Command(0x28);    //

}


//=======Exiting Sleep Mode=============
void EXIT_SLEEP(void)
{
     Write_Command(0x2A);   /*  RE : 1  ; IS : 0  ; SD : 0 */
     Write_Command(0x79);   //* RE : 1  ; IS : 0  ; SD : 1 */

     Write_Command(0x71);   //Set Regulator

     Write_Data(0x5C);    //Enable internal Vdd regulator at 5V I/O application mode

     Write_Command(0xDC);   //Set VSL & GPIO (Vcc)On
     Write_Command(0x03);    //

     Write_Command(0x78);   /*  RE : 1  ; IS : 0  ; SD : 0 */
     Write_Command(0x28);   /*  RE : 0  ; IS : 0  ; SD : 0 */
     Write_Command(0x0C);    //Display ON
}
//////////////////////////////////////////////////////////////////////////////////
//void STP_SC(void)
//{
  //  while(S_S)
  //  {
   //  if(STP==1)
   //  {
   //     delay(1);
  //      break; }
  //  }
//}

//////////////////////////////////////////////////////////////////////////////////

void main(void)
{
    delay(10);//Delay
    CS= 0 ;//CS SET LOW
    Initial_SSD1311();

    while(1)
    {

        FULL_ON();
        delay(20);
       // STP_SC();


        SHOW_CHARABCD();
        delay(20);
       // STP_SC();

        CK_SHORT1();
        delay(20);
       // STP_SC();

        CK_SHORT2();
        delay(20);
       // STP_SC();

        SQUARE();
        delay(20);
        //STP_SC();

        CROSS_DOT();
        delay(20);
       // STP_SC();

        CROSS_DOT2();
        delay(20);
        //STP_SC();
    }
}

