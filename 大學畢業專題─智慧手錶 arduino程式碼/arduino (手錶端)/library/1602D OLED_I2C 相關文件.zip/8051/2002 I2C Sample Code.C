//=============================================================
//    OLED MODULE 1602  2002   I2C   SAMPLE CODE
//    Contraller :
//    Author     :
//    history     :
//==============================================================

#include <reg51.h>
#include <intrins.h>

#define	uchar	unsigned char
#define	uint	unsigned int

#define Write_Address 0x78/*slave addresses with write*/
#define Read_Address 0x79/*slave addresses with read*/

sbit SDA=P1^1;/*I2C serial data).*/
sbit SCL=P1^0;/*I2C serial clock).*/
sbit 	RES=P3^1;
bit 	log=0;
sbit	int0=P2^1;


void OLED_initialize(void);
void Write_CGRAM(uchar  a[]);
void Busy(void);
void Delay(uint n);
void Delay1(uint n);
void Write_DDRAM(uchar a);
void write_CGROM(uchar a);
void show_character_string(uchar a[]);
void Start(void);
void Stop(void);
void Check_Ack(void);
void Send_ACK(void);
void SentByte(unsigned char Byte);
unsigned char ReceiveByte(void);
void horizontal_scroll(void);
void shift_to_right(void);
void shift_to_left(void);

uchar code character_string[]=
{
		" PI-TEK OLED        "
		" HIGH CONTRAST      "
};

uchar code font[]=
{
	0x1f,0x00,0x1f,0x00,0x1f,0x00,0x1f,0x00,
	0x00,0x1f,0x00,0x1f,0x00,0x1f,0x00,0x1f,
	0x15,0x15,0x15,0x15,0x15,0x15,0x15,0x15,
	0x0a,0x0a,0x0a,0x0a,0x0a,0x0a,0x0a,0x0a,
	0x08,0x0f,0x12,0x0f,0x0a,0x1f,0x02,0x02,	//
	0x0f,0x09,0x0f,0x09,0x0f,0x09,0x09,0x13,	//
	0x1f,0x11,0x11,0x1f,0x11,0x11,0x11,0x1F,	//
	0x0C,0x0a,0x11,0x1f,0x09,0x09,0x09,0x13,	//
};



void Step(void) interrupt 0 using 0
{
	Delay1(500);
	if(int0==0)	log=!log;
   while(!int0);
  return;

}

void Delay1(uint n)
{while(n--);
   
}

void Delay(uint n)
{while(n)
 { 
	  n--;
 }
 	for(;log==1;)
	{

	}

}

void Start(void)
{	SDA=1;
	SCL=1;
    _nop_();
	SDA=0;
    _nop_();
	SCL=0;
}	


void Stop(void)
{
	SCL=0;
	SDA=0;
    _nop_();
	SCL=1;
    _nop_();
	SDA=1;
}

void Check_Ack(void)//Acknowledge
{
    unsigned char ack=1;
	SDA=1;
    SCL=1;
    _nop_();
    while(ack==1){ack=SDA;}
    _nop_();
    SCL=0;
    return;
}

void Send_ACK(void)
{	SCL=0;
	SDA=0;
    _nop_();	
	SCL=1;
    _nop_();
	SCL=0;
}

void Busy(void)
{uchar busy=0x80;
while((busy&0x80)==0x80)
 {	 Start();
	 SentByte(Read_Address); /*slave addresses with read*/
	 SentByte(0x80);			//Continuation bit  command
	 busy=ReceiveByte();
 	 Stop();
 }
}

void SentByte(unsigned char Byte)
{
	uchar i;
	for(i=0;i<8;i++)
     {  SCL=0;
        if((Byte&0x80)==0x80) SDA=1;
       	else SDA=0;
       	SCL=1;
        _nop_();		
        Byte=Byte<<1;
     }
	SCL=0;
	Check_Ack();
	 Delay(200);	
}
 

unsigned char ReceiveByte(void)
{uchar i,rudata=0;
	SCL=0;
	SDA=1;
	for(i=0;i<8;i++)
     {  SCL=1;
    	_nop_();	
		if (SDA==1)rudata|=0x01;
		else rudata|=0x00;
        rudata=rudata<<1;
		SCL=0;
        _nop_();	
     }	
	Send_ACK();
	return rudata;
}



void Write_CGRAM(uchar  a[])
{
  uchar i=64,k;

	 Start();
	 SentByte(Write_Address); //slave addresses with write
	 SentByte(0x80);			//Continuation bit  command
	SentByte(0x40);           //CORMA address
	SentByte(0x40);			//Continuation bit  data 
	for(k=0;k<64;k++)
	{SentByte(a[k]);
	}
 	 Stop();
}

void OLED_initialize(void)
{
	 RES=0;
	 Delay(200);
	 RES=1;
	 Delay(200);

	 Start();
	 SentByte(Write_Address); //slave addresses with write
	 SentByte(0x80);			//Continuation bit  command
	 SentByte(0x2a);  			//RE=1
	 SentByte(0x80);			//Continuation bit   command	 	 	 	 
	 SentByte(0x71);  //Function Selection A
	 SentByte(0xc0);			//Continuation bit  data
	 SentByte(0x00);	//Disable internal VDD
	 SentByte(0x80);			//Continuation bit   command
	 SentByte(0x28);  //RE=0,IS=0
	 SentByte(0x80);			//Continuation bit   command
	 SentByte(0x08);  //display OFF

	 SentByte(0x80);			//Continuation bit   command
	 SentByte(0x2a);  //RE=1
	 SentByte(0x80);			//Continuation bit   command
	 SentByte(0x79);  //SD=1  OLED command set is enabled
	 SentByte(0x80);			//Continuation bit   command
	 SentByte(0xD5);  //Set Display Clock Divide Ratio/ Oscillator Frequency 
	 SentByte(0x80);			//Continuation bit   command
	 SentByte(0x70);  
	 SentByte(0x80);			//Continuation bit   command
	 SentByte(0x78);  //SD=0   OLED command set is disabled
	 SentByte(0x80);			//Continuation bit   command
	 SentByte(0x08);  //5-dot font width, black/white inverting of cursor disable, 1-line or 2-line display mode			 //08:2 09:4line	
	 SentByte(0x80);			//Continuation bit   command
	 SentByte(0x06);  //COM0 -> COM31  SEG99 -> SEG0,
	 SentByte(0x80);			//Continuation bit   command
	 SentByte(0x72);  //Function Selection B. Select the character no. of character generator    Select character ROM
	 SentByte(0xC0);			//Continuation bit  data
	 SentByte(0x09);  //01:ROMA 05:ROMB 09:ROMC

	 SentByte(0x80);			//Continuation bit   command
	 SentByte(0x2a);  //RE=1
	 SentByte(0x80);			//Continuation bit   command
	 SentByte(0x79);  //SD=1  OLED command set is enabled
	 SentByte(0x80);			//Continuation bit   command
	 SentByte(0xDA);  //Set SEG Pins Hardware Configuration  
	 SentByte(0x80);			//Continuation bit   command
	 SentByte(0x10);  //Alternative (odd/even) SEG pin configuration, Disable SEG Left/Right remap
	 SentByte(0x80);			//Continuation bit   command
	 SentByte(0xDC);  //Function Selection C  Set VSL & GPIO 
  	 SentByte(0x80);			//Continuation bit   command
	 SentByte(0x03);  //Internal VSL  represents GPIO pin HiZ, input disabled (always read as low)
	 SentByte(0x80);			//Continuation bit   command
	 SentByte(0x81);  //Set Contrast Control 
 	 SentByte(0x80);			//Continuation bit   command 
	 SentByte(0xFF);  
	 SentByte(0x80);			//Continuation bit   command
	 SentByte(0xD9);  //Set Phase Length 
 	 SentByte(0x80);			//Continuation bit   command 
	 SentByte(0xF1); 
 	 SentByte(0x80);			//Continuation bit   command
	 SentByte(0xDB);  //Set VCOMH Deselect Level 
 	 SentByte(0x80);			//Continuation bit   command
	 SentByte(0x40);  //

	 SentByte(0x80);			//Continuation bit   command
	 SentByte(0x78);  //SD=0   OLED command set is disabled

	 SentByte(0x80);			//Continuation bit   command
	 SentByte(0x28);  //RE=0,IS=0
	 SentByte(0x80);			//Continuation bit   command
	 SentByte(0x01);  //Clear Display
	 SentByte(0x80);			//Continuation bit   command
	 SentByte(0x80);  //Set DDRAM Address



	 SentByte(0x80);			//Continuation bit   command
	 SentByte(0x0C);  //Display ON
 	 Stop();

	 Write_CGRAM(font);


}

void Write_DDRAM(uchar a)
{uchar j;
///////////////////////////////////////////////////////////////
	 Start();
	 SentByte(Write_Address); //slave addresses with write
	 SentByte(0x80);			//Continuation bit  command

 	SentByte(0x80);			//set 1,st line DDRAM address
	SentByte(0x40);			//Continuation bit  data  
	for(j=0;j<20;j++)
	{SentByte(a);
	}
 	 Stop();

///////////////////////////////////////////////////////////////
	 Start();
	 SentByte(Write_Address); //slave addresses with write
	 SentByte(0x80);			//Continuation bit  command
 
 	SentByte(0xc0);		//set 3st line DDRAM address
	SentByte(0x40);			//Continuation bit  data 
	for(j=0;j<20;j++)
	{SentByte(a);
	}
 	 Stop();

//////////////////////////////////////////////////////////////

		Delay(35000);
		Delay(65000);
}



void show_character_string(uchar a[])
{uchar j;
	 Start();
	 SentByte(Write_Address); //slave addresses with write

	SentByte(0x80);			//Continuation bit  command
 	SentByte(0x80);			//set 1 1ine DDRAM address
	SentByte(0x40);			//Continuation bit  data 
 	for(j=0;j<20;j++)
	{SentByte(a[j]);
	}
 	 Stop();

	 Start();
	 SentByte(Write_Address); //slave addresses with write
	 SentByte(0x80);			//Continuation bit  command
 	SentByte(0xc0);		//set 2 line DDRAM address
	SentByte(0x40);			//Continuation bit  data 
 	for(j=20;j<40;j++)
	{SentByte(a[j]);
	}
 	 Stop();
		Delay(35000);
		Delay(65000);
}


void write_CGROM(uchar a)
{uchar j;
	 Start();
	 SentByte(Write_Address); //slave addresses with write
	SentByte(0x80);			//Continuation bit  command
 	SentByte(0x80);			//set line DDRAM address
	SentByte(0x40);			//Continuation bit  data
 	for(j=0;j<20;j++)
	{SentByte(a);a+=1;
	}
 	 Stop();


	 Start();
	 SentByte(Write_Address); //slave addresses with write
	 SentByte(0x80);			//Continuation bit  command
 	SentByte(0xc0);		//set line DDRAM address
	SentByte(0x40);			//Continuation bit  data 
	for(j=0;j<20;j++)
	{SentByte(a);a+=1;
	}
	 Stop();

		Delay(35000);
		Delay(65000);
}

void shift_to_left(void)
{uchar x;
	Start();
	 SentByte(Write_Address); //slave addresses with write
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x2a);
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x78); 
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x29);
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x2a);
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x1f);
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x28);
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x2a);
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x1d);
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x28);

	for(x=0;x<20;x++)
	{
		SentByte(0x80);			//Continuation bit  data
		SentByte(0x1c);          //shift left
		Delay(30000);
	}
		 Stop();
}

void shift_to_right(void)
{uchar x;
	Start();
	 SentByte(Write_Address); //slave addresses with write
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x2a);
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x78); 
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x29);
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x2a);
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x1f);
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x28);
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x2a);
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x1d);
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x28);

	for(x=0;x<20;x++)
	{
		SentByte(0x80);			//Continuation bit  data
		SentByte(0x18);          //shift right
		Delay(30000);
	}
		 Stop();
}

void horizontal_scroll(void)
{uchar i;
	Start();
	 SentByte(Write_Address); //slave addresses with write
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x2a);
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x78); 
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x29);
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x2a);
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x1f);
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x28);
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x2a);
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x1c);
	for(i=0x80;i<0xc0;i++)
	{
		SentByte(0x80);			//Continuation bit  data	
		SentByte(i);
		Delay(10000);
	}
	SentByte(0x80);			//Continuation bit  command
	SentByte(0x28);
		 Stop();
}


void main(void)
{uchar a=0x81;
	IE=0x81;
	IP=0x01;
	TCON=0x01;
	int0=1;
	P1=0xff;
	P2=0xff;
	Delay(1000);
	OLED_initialize();
while(1)

	{
	

   	show_character_string(character_string);				 
	
	Write_DDRAM(0xE5);	
	Write_DDRAM(0xE6);
	Write_DDRAM(0xE7);
	Write_DDRAM(0x10);
	Write_DDRAM(4);	
	Write_DDRAM(5);
	Write_DDRAM(6);
	Write_DDRAM(7);

	write_CGROM(0xB1);

	Delay(65000);	
	}
}




